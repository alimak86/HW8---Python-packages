from datetime import datetime
import random

JANUARY = 1
FEBRUARY = 2
MARCH = 3
APRIL = 4
MAY = 5
JUNE = 6
JULY = 7
AUGUST = 8
SEPTEMBER = 9
OCTOBER = 10
NOVEMBER = 11
DECEMBER = 12

names = ["Alisa", "Kolia", "Viktor", "Ruslan", "Nikita", "Vladimir", "Katia", "Irina", "Vladislav", "Rostislav", "Miroslav", "Olga", "Daria"]

days = {JANUARY:31, FEBRUARY:28, MARCH: 31, APRIL: 30, MAY: 31, JUNE: 30, JULY : 31, AUGUST: 31, SEPTEMBER: 30, OCTOBER : 31, NOVEMBER: 30, DECEMBER: 31}

YEAR = 2023 ## will generate random dates for the 2023 year - just for testing

def get_day(month): ## return random day for the month
	min_day = 1 ## minimum days in the month
	max_day = days[month] ## maximum days in the month
	return random.randint(min_day, max_day)

def get_month(): ## return random month number
	return random.randint(MARCH,MARCH) ### only for testing

def get_date(): ## returns random date in 2023 year
	mois = get_month() ## get month
	jour = get_day(mois) ## get day
	date = datetime(year = YEAR, month = mois, day = jour) ## generate the date
	return date

def list_generator(number): ## generates a dictionary of the users and their birthdays
	###3print("generator: ",number)
	users = {} ## empty dictionary
	for i in range(number):
		random.shuffle(names)
		name = random.randint(0,len(names)-1) ## get name randomly
		###############print(names[name])
                birthday = get_date() ## generate random date
		users[names[name]] = birthday
	return users


