from generator import *
from calculator import *
import sys
import datetime

MAX_EXPECTED = 100

WEEK = {MONDAY: "Monday", TUESDAY: "Tuesday", WEDNESDAY: "Wednesday", THURSDAY: "Thursday", FRIDAY: "Friday", SATURDAY: "Saturday", SUNDAY: "Sunday"}

def in_range(date, datetime1, datetime2):
	return date.day >= datetime1.day and date.day <= datetime2.day and \
               date.month >= datetime1.month and date.month <= datetime2.month

def congrats(users):
	congratulations = {}
	for i in range(len(WEEK)):
		congratulations[i] = []

	for user in users:
		if in_range(users[user], current_weekend(), next(FRIDAY)):
			if users[user].weekday() == SATURDAY or users[user].weekday() == SUNDAY:
				congratulations[MONDAY].append(user)
			else:
				congratulations[users[user].weekday()].append(user)
	return congratulations

def listtstr(list):
	out=""
	for a in list:
		out+=str(a) + " "
	return out

def print_congrats(list):
	for day in list:
		if len(list[day]) > 0:
			print(WEEK[day] + " : " + listtstr(list[day]))
	return 0

def get_birthdays_per_week(users):
	print_congrats(congrats(users))
	return 0	

if __name__ == "__main__":

	## default values
	number = MAX_EXPECTED ## just default 
	filename = "output.txt"
	debug = False

	for i in range(1,len(sys.argv)):
		if sys.argv[i] == "-n":
			try:
				number = sys.argv[i+1] ## read number of users
			except IndexError:
				print("there is no number written assume number: 100")
		if sys.argv[i] == "-f":
			try:
				filename = sys.argv[i+1] ## read filename
			except IndexError:
				print("there is no filename indicated use: output.txt")
		if sys.argv[i] == "-debug":
			debug = True

	if debug:
		users = list_generator(int(number)) ## generate users
		##### list of users may conatin less amount than demanded - dictionary limitation
        	##### for the proper list of users should be generated in other way - not dictionary as name: birthday
        	##### in this case it is impossible to have two collegues with the similar names but different birth days
		print("#######################################################################################")
		for val in users:
			print(val + ":" + users[val].date().strftime("%A %d %B %Y"))
		print("#######################################################################################")
	
		##print(current_weekend().date())
		##print(next(FRIDAY).date())
		##print(congrats(users))
		print("Today is {:}".format(datetime.date.today()))
		print("Next week birthdays have:")
		get_birthdays_per_week(users)
	else:
		print("use -debug to try test example")

