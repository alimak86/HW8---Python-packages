import datetime
import time

MONDAY = 0
TUESDAY = 1
WEDNESDAY = 2
THURSDAY = 3
FRIDAY = 4
SATURDAY = 5
SUNDAY = 6

ONE_WEEK = 1

def current():
	return datetime.datetime.now()

def current_day():
	return current().day

def current_weekend():
	delta = SATURDAY - current().weekday()
	if delta < 0 :
		delta = 0
	return current() + datetime.timedelta(days = delta)

def next(day1):
	current_day = datetime.datetime( 
                                year = current().year, 
                                month = current().month, 
                                day = current().day + day1 - current().weekday()
                                       ) ## current day
	next_day = current_day + datetime.timedelta(weeks = ONE_WEEK)
	return next_day
